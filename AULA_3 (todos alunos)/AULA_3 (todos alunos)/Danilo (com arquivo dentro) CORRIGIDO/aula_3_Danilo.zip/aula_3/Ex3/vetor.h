#ifndef VETOR_H
#define VETOR_H

#define MAX 100

void removerRepetidos(int vetor[], int *tamanho);
void ordenarVetor(int vetor[], int tamanho);
void mostrarVetor(int vetor[], int tamanho);

#endif