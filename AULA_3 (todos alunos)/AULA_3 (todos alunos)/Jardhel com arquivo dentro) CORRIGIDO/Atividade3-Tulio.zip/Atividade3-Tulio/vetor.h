#ifndef VETOR_H
#define VETOR_H

void lerVetor(int *vet, int n);
void imprimirVetor(int *vet, int n);
int removerDuplicados(int *vet, int n);

#endif
