#include <stdio.h>

#define MAX 20

int main() {
    float notas[MAX];
    int total = 0;
    int opcao, pos, i;
    float soma, maior, menor;

    do {
        printf("\n1 - Inserir nota");
        printf("\n2 - Remover nota");
        printf("\n3 - Atualizar nota");
        printf("\n4 - Mostrar notas");
        printf("\n0 - Sair");
        printf("\nOpcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            if (total < MAX) {
                printf("Digite a nota: ");
                scanf("%f", &notas[total]);
                total++;
            } else {
                printf("Vetor cheio!\n");
            }
        }

        else if (opcao == 2) {
            printf("Posicao da nota: ");
            scanf("%d", &pos);

            if (pos >= 0 && pos < total) {
                for (i = pos; i < total - 1; i++) {
                    notas[i] = notas[i + 1];
                }
                total--;
                printf("Nota removida!\n");
            } else {
                printf("Posicao invalida!\n");
            }
        }

        else if (opcao == 3) {
            printf("Posicao da nota: ");
            scanf("%d", &pos);

            if (pos >= 0 && pos < total) {
                printf("Nova nota: ");
                scanf("%f", &notas[pos]);
                printf("Nota atualizada!\n");
            } else {
                printf("Posicao invalida!\n");
            }
        }

        else if (opcao == 4) {
            if (total == 0) {
                printf("Nenhuma nota cadastrada.\n");
            } else {
                soma = 0;
                maior = menor = notas[0];

                for (i = 0; i < total; i++) {
                    printf("[%d] %.2f\n", i, notas[i]);
                    soma += notas[i];
                    if (notas[i] > maior) maior = notas[i];
                    if (notas[i] < menor) menor = notas[i];
                }

                printf("Media: %.2f\n", soma / total);
                printf("Maior: %.2f\n", maior);
                printf("Menor: %.2f\n", menor);
            }
        }

    } while (opcao != 0);

    return 0;
}
