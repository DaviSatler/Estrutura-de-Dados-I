#include <stdio.h>
#include <string.h>
#define MAX 100
/* Ele está classificado em O(n). */
int main() {
    int codigo[MAX], quantidade[MAX];
    char nome[MAX][50];

    int total = 0;
    int opcao, i, pos, cod, novaQtd;
    int existe;


    do {
        printf("\n Controle de estoque");
        printf("\n1 - Cadastrar produto");
        printf("\n2 - Atualizar quantidade");
        printf("\n3 - Remover produtos");
        printf("\n4 - Listar produtos");
        printf("\n0 - Sair");
        printf("\nOpcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            if (total >= MAX) {
                printf("Estoque cheio!\n");
            } else {
                printf("Codigo do produto: ");
                scanf("%d", &cod);

                existe = 0;
                for (i = 0; i < total; i++) {
                    if (codigo[i] == cod) {
                        existe = 1;
                        break;
                    }
                }

                if (existe) {
                    printf("Codigo ja existente!\n");
                } else {
                    codigo[total] = cod;

                    printf("Nome do produto: ");
                    scanf(" %[^\n]", nome[total]);

                    do {
                        printf("Quantidade: ");
                        scanf("%d", &quantidade[total]);
                    } while (quantidade[total] < 0);

                    total++;
                    printf("Produto cadastrado!\n");
                }
            }
        }

        else if (opcao == 2) {
            printf("Codigo do produto: ");
            scanf("%d", &cod);

            pos = -1;
            for (i = 0; i < total; i++) {
                if (codigo[i] == cod) {
                    pos = i;
                    break;
                }
            }

            if (pos == -1) {
                printf("Produto nao encontrado!\n");
            } else {
                do {
                    printf("Nova quantidade: ");
                    scanf("%d", &novaQtd);
                } while (novaQtd < 0);

                quantidade[pos] = novaQtd;
                printf("Quantidade atualizada!\n");
            }
        }

        
        else if (opcao == 3) {
            printf("Codigo do produto: ");
            scanf("%d", &cod);

            pos = -1;
            for (i = 0; i < total; i++) {
                if (codigo[i] == cod) {
                    pos = i;
                    break;
                }
            }

            if (pos == -1) {
                printf("Produto nao encontrado!\n");
            } else {
                for (i = pos; i < total - 1; i++) {
                    codigo[i] = codigo[i + 1];
                    strcpy(nome[i], nome[i + 1]);
                    quantidade[i] = quantidade[i + 1];
                }
                total--;
                printf("Produto removido!\n");
            }
        }

        else if (opcao == 4) {
            if (total == 0) {
                printf("Nenhum produto cadastrado.\n");
            } else {
                printf("\nCodigo | Nome | Quantidade\n");
                for (i = 0; i < total; i++) {
                    printf("%d | %s | %d\n",
                           codigo[i], nome[i], quantidade[i]);
                }
            }
        }

    } while (opcao != 0);

    return 0;
}
