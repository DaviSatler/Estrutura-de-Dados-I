#include <stdio.h>
#include <stdlib.h>
#include "core.h" 

int cadastrar (void *caixa, int tamanho, char *arquivo) { 

          printf("Cadastrando aluno...\n");
          FILE *arquivo = fopen(arquivo, "ab");
           if (arquivo == NULL) {
                    printf("Erro Crítico: Não foi possível abrir o arquivo para escrita!\n");
                    return 0;
          }
          fwrite(caixa, tamanho, 1, arquivo);
          fclose(arquivo);
          printf("Dado cadastrado com sucesso!\n");
          return 1;
      
}

void exibir(char *arquivo, int tamanho, void (*imprimir)(void*)) {
          FILE *arquivo = fopen(arquivo, "rb");
           if (arquivo == NULL) {
                    printf("Aviso: Nenhum dado encontrado (o arquivo ainda nao existe).\n");
                    return;
          }

           void *buffer = malloc(tamanho);

           while (fread(buffer, tamanho, 1, arquivo)) {
                    imprimir(buffer);    
           }

           free(buffer);
           fclose(arquivo);
           
};