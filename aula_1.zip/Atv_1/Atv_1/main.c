#include "menus.h"

int main(void) {
    menu_principal();
    return 0;
}
