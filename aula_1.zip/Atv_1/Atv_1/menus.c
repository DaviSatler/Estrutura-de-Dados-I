#include <stdio.h>
#include <stdlib.h>
#include "menus.h"

/* includes das pastas */
#include "Aluno/aluno.h"
#include "Carro/carro.h"
#include "Cliente/cliente.h"
#include "Conta_bancaria/conta_bancaria.h"
#include "Endereco/endereco.h"
#include "Filme/filme.h"
#include "Funcionario/funcionario.h"
#include "Livro/livro.h"
#include "Produto/produto.h"
#include "Professor/professor.h"

void limpar_tela(void) {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void pausar(void) {
    printf("\nPressione ENTER para voltar...");
    getchar();
    getchar();
}

void menu_principal(void) {
    int opcao;

    do {
        limpar_tela();
        printf("====== MENU PRINCIPAL ======\n");
        printf(" 1 - Aluno\n");
        printf(" 2 - Carro\n");
        printf(" 3 - Cliente\n");
        printf(" 4 - Conta Bancaria\n");
        printf(" 5 - Endereco\n");
        printf(" 6 - Filme\n");
        printf(" 7 - Funcionario\n");
        printf(" 8 - Livro\n");
        printf(" 9 - Produto\n");
        printf("10 - Professor\n");
        printf(" 0 - Sair\n");
        printf("============================\n");
        printf("Opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1: menu_aluno(); break;
            case 2: menu_carro(); break;
            case 3: menu_cliente(); break;
            case 4: menu_conta_bancaria(); break;
            case 5: menu_endereco(); break;
            case 6: menu_filme(); break;
            case 7: menu_funcionario(); break;
            case 8: menu_livro(); break;
            case 9: menu_produto(); break;
            case 10: menu_professor(); break;

            case 0:
                printf("\nEncerrando...\n");
                break;

            default:
                printf("\nOpcao invalida!\n");
        }

        if (opcao != 0)
            pausar();

    } while (opcao != 0);
}
