#ifndef MENUS_H
#define MENUS_H

void limpar_tela(void);
void pausar(void);
void menu_principal(void);

#endif
