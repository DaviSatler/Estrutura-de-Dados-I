#ifndef MENUS_H
#define MENUS_H

void limpar_tela();
void pausar();

void menu_alunos();
void menu_carros();
void menu_clientes();
void menu_conta_bancaria();
void menu_endereco();
void menu_filme();
void menu_funcionario();
void menu_livro();
void menu_produto();
void menu_professor();

#endif